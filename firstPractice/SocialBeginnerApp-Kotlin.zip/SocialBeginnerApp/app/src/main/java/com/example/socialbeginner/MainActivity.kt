package com.example.socialbeginner

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Chat
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.MoreHoriz
import androidx.compose.material.icons.outlined.Savings
import androidx.compose.material.icons.outlined.Work
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.socialbeginner.ui.screens.*
import com.example.socialbeginner.ui.theme.*

enum class AppTab(val label: String, val icon: ImageVector) {
    HOUSING("주거", Icons.Outlined.Home),
    ASSETS("자산", Icons.Outlined.Savings),
    EMPLOYMENT("취업", Icons.Outlined.Work),
    MORE("더보기", Icons.Outlined.MoreHoriz),
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            SocialBeginnerTheme {
                MainScreen()
            }
        }
    }
}

@Composable
fun MainScreen() {
    var activeTab by rememberSaveable { mutableStateOf(AppTab.HOUSING) }
    var chatOpen by rememberSaveable { mutableStateOf(false) }

    Box(Modifier.fillMaxSize().background(Background)) {
        Column(Modifier.fillMaxSize().systemBarsPadding()) {
            // 상단 헤더
            Surface(color = Background) {
                Column {
                    Text(
                        activeTab.label,
                        Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp),
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = Foreground,
                    )
                    HorizontalDivider(color = BorderColor)
                }
            }

            // 탭 콘텐츠
            Box(Modifier.weight(1f)) {
                when (activeTab) {
                    AppTab.HOUSING -> HousingScreen()
                    AppTab.ASSETS -> AssetsScreen()
                    AppTab.EMPLOYMENT -> EmploymentScreen()
                    AppTab.MORE -> MoreScreen()
                }
            }

            // 하단 탭바
            Surface(color = CardColor, shadowElevation = 8.dp) {
                Column {
                    HorizontalDivider(color = BorderColor)
                    Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp)) {
                        AppTab.entries.forEach { tab ->
                            val active = activeTab == tab
                            Column(
                                Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { activeTab = tab }
                                    .padding(vertical = 10.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                            ) {
                                Icon(
                                    tab.icon,
                                    contentDescription = tab.label,
                                    tint = if (active) Primary else MutedForeground,
                                    modifier = Modifier.size(22.dp),
                                )
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    tab.label,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = if (active) Primary else MutedForeground,
                                )
                                Spacer(Modifier.height(3.dp))
                                Box(
                                    Modifier
                                        .size(width = 16.dp, height = 2.dp)
                                        .clip(RoundedCornerShape(100.dp))
                                        .background(if (active) Primary else Color.Transparent)
                                )
                            }
                        }
                    }
                }
            }
        }

        // 챗봇 FAB
        if (!chatOpen) {
            FloatingActionButton(
                onClick = { chatOpen = true },
                containerColor = Primary,
                contentColor = Color.White,
                shape = RoundedCornerShape(100.dp),
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(end = 16.dp, bottom = 96.dp),
            ) {
                Icon(Icons.Outlined.Chat, contentDescription = "AI 도우미 열기")
            }
        }

        // 챗봇 오버레이
        if (chatOpen) {
            BackHandler { chatOpen = false }
            Box(Modifier.fillMaxSize().systemBarsPadding().imePadding()) {
                ChatbotOverlay(onClose = { chatOpen = false })
            }
        }
    }
}
