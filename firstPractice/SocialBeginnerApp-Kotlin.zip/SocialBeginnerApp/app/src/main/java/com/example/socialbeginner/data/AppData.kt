package com.example.socialbeginner.data

// ─── 주거 ────────────────────────────────────────────────────────
data class ContractTip(val id: Int, val title: String, val desc: String, val tag: String)

val contractTips = listOf(
    ContractTip(1, "계약 전 등기부등본 확인", "근저당권, 압류, 가처분 등 권리관계를 반드시 확인하세요.", "필수"),
    ContractTip(2, "전입신고 + 확정일자 받기", "계약 후 14일 이내 전입신고, 주민센터에서 확정일자 도장을 받으면 보증금 보호.", "필수"),
    ContractTip(3, "특약사항 꼼꼼히 체크", "도배·장판 교체, 시설 수리 책임 범위를 계약서에 명시하세요.", "권장"),
    ContractTip(4, "중개수수료 상한액 확인", "보증금·월세 금액에 따라 법정 최대 수수료가 다릅니다. 초과 요구 시 거부 가능.", "참고"),
    ContractTip(5, "임대인 신분 확인", "계약 시 임대인의 신분증과 등기부등본상 소유자가 동일한지 대조하세요.", "필수"),
)

val checklistItems = listOf(
    1 to "햇빛과 채광 확인 (남향 여부)",
    2 to "수압·온수 직접 테스트",
    3 to "벽면·천장 곰팡이 및 누수 흔적",
    4 to "콘센트 위치와 개수 확인",
    5 to "방음 상태 확인 (이웃 소음)",
    6 to "관리비 항목 및 금액 확인",
    7 to "주차 공간 및 자전거 보관",
    8 to "쓰레기 분리수거 방법 확인",
    9 to "엘리베이터 유무 (층수 고려)",
    10 to "인근 편의시설 (편의점, 마트, 병원)",
)

data class TroubleItem(val id: Int, val icon: String, val title: String, val steps: List<String>)

val troubleshootingItems = listOf(
    TroubleItem(1, "💧", "수도 누수 발생", listOf("관할 지역 상수도사업본부(120)에 신고", "임대인에게 즉시 연락 후 문자/카톡으로 증거 남기기", "수리 완료 시 영수증 보관")),
    TroubleItem(2, "❄️", "보일러·난방 고장", listOf("임대인에게 즉시 연락", "제조사 AS센터 번호 확인 (보일러 본체에 스티커)", "겨울철 동파 방지는 임차인 관리 의무")),
    TroubleItem(3, "🔐", "열쇠·도어락 분실", listOf("임시 잠금 서비스 (동네 열쇠방 또는 119)", "임대인 동의 후 교체 비용 협의", "교체 영수증 보관 후 퇴실 시 정산")),
    TroubleItem(4, "🪲", "해충·바퀴벌레 출몰", listOf("관할 구청 방역팀 무료 방제 신청 가능", "자체 방역 후에도 재발 시 임대인과 비용 협의", "입주 전 상태를 사진으로 기록해두기")),
)

data class TermItem(val term: String, val def: String)

val housingTerms = listOf(
    TermItem("전세", "보증금을 맡기고 월세 없이 거주하는 방식. 계약 종료 시 보증금 반환."),
    TermItem("월세", "매달 일정 금액을 집주인에게 지불하는 방식."),
    TermItem("반전세", "전세에서 일부를 월세로 전환한 혼합 방식."),
    TermItem("관리비", "건물 유지·관리에 드는 비용. 공용전기·수도·청소비 등 포함."),
    TermItem("중개수수료", "부동산 중개업자에게 지불하는 수수료. 법정 상한이 있음."),
    TermItem("확정일자", "임대차 계약서에 주민센터가 날짜를 확인해주는 제도. 보증금 보호."),
    TermItem("전입신고", "새 주소지를 주민센터에 신고하는 것. 법적 거주지 확정."),
    TermItem("근저당", "집에 설정된 대출 담보. 경매 시 보증금보다 먼저 변제될 수 있음."),
)

// ─── 자산 ────────────────────────────────────────────────────────
data class CheongyakStep(val step: String, val title: String, val desc: String, val highlight: Boolean = false)

val cheongyakSteps = listOf(
    CheongyakStep("01", "청약통장 개설", "주택청약종합저축 — 만 19세 이상 누구나 개설 가능. 1인 1계좌.", highlight = true),
    CheongyakStep("02", "납입 횟수 쌓기", "매월 2만~50만 원 납입. 공공주택은 납입 횟수, 민영주택은 납입금액이 중요."),
    CheongyakStep("03", "청약 자격 확인", "무주택 여부, 세대원 수, 소득 기준을 청약홈(www.applyhome.co.kr)에서 확인."),
    CheongyakStep("04", "분양 공고 확인", "청약홈 공고 확인 후 청약 일정, 분양가, 타입 비교."),
    CheongyakStep("05", "청약 신청", "모바일 또는 은행 창구에서 청약 신청. 당첨 시 계약금 준비."),
    CheongyakStep("06", "당첨 후 대출 준비", "디딤돌 대출, 버팀목 대출 등 정부 저금리 상품 확인."),
)

data class Policy(val id: Int, val tag: String, val title: String, val desc: String, val deadline: String)

val governmentPolicies = listOf(
    Policy(1, "주거", "청년 월세 한시 특별지원", "만 19~34세, 월 최대 20만 원씩 최대 12개월 지원.", "연중 접수"),
    Policy(2, "금융", "청년희망적금", "연 최대 9.3% 금리 혜택. 만기 시 정부 저축장려금 지급.", "선착순 마감"),
    Policy(3, "주거", "버팀목 전세자금 대출", "중소기업 취업청년 연 1.2% 초저금리. 최대 1억 원.", "연중"),
    Policy(4, "취업", "청년내일채움공제", "2년 근속 시 1,200만 원 목돈 마련. 청년·기업·정부 공동 적립.", "연중"),
    Policy(5, "복지", "국민건강보험 지역가입자 감면", "소득 없는 청년 피부양자 자격 유지 또는 보험료 경감.", "연중"),
    Policy(6, "교육", "국가장학금 (한국장학재단)", "소득분위별 최대 전액 지원. 매 학기 신청.", "학기별 신청"),
)

val policyFilters = listOf("전체", "주거", "금융", "취업", "복지", "교육")

// ─── 취업 ────────────────────────────────────────────────────────
data class ContractGuideItem(val id: Int, val title: String, val desc: String, val important: Boolean = false)

val contractGuideItems = listOf(
    ContractGuideItem(1, "근로계약서는 반드시 서면으로", "구두 계약은 분쟁 시 증명 불가. 계약서 사본은 내가 보관해야 합니다.", important = true),
    ContractGuideItem(2, "4대 보험 가입 여부 확인", "국민연금, 건강보험, 고용보험, 산재보험. 10인 미만 사업장도 의무 가입.", important = true),
    ContractGuideItem(3, "임금 항목 세부 확인", "기본급, 수당, 상여금 등 항목별 금액이 명시되어야 합니다."),
    ContractGuideItem(4, "근로시간 및 휴게시간", "주 40시간 + 연장수당. 4시간 근무 시 30분, 8시간 시 1시간 휴게."),
    ContractGuideItem(5, "수습 기간과 급여", "수습 3개월은 최저임금의 90%까지 지급 가능 (단, 단순노무직 제외)."),
    ContractGuideItem(6, "퇴직금 규정", "1년 이상 근무, 주 15시간 이상 시 퇴직금 발생. 퇴직 후 14일 이내 지급."),
)

data class JobCategory(val id: Int, val icon: String, val name: String, val sites: List<String>, val tip: String)

val jobCategories = listOf(
    JobCategory(1, "💻", "IT·개발", listOf("사람인", "원티드", "점핏"), "포트폴리오 필수. GitHub 관리 중요."),
    JobCategory(2, "📊", "경영·사무", listOf("잡코리아", "사람인", "공공기관채용"), "엑셀, 한컴오피스 자격증 우대."),
    JobCategory(3, "🎨", "디자인·크리에이티브", listOf("원티드", "크몽", "사람인"), "포트폴리오 사이트 필수. 툴 숙련도 강조."),
    JobCategory(4, "🏥", "의료·복지", listOf("복지넷", "사람인", "워크넷"), "자격증 종류와 경력 중심 지원."),
    JobCategory(5, "🍳", "외식·서비스", listOf("알바몬", "알바천국", "사람인"), "초단기부터 정규직까지. 시급 꼭 확인."),
    JobCategory(6, "🏗️", "건설·생산", listOf("워크넷", "고용24", "사람인"), "기능사 이상 자격증 보유 시 우대."),
)

val jobSites = listOf("사람인", "잡코리아", "원티드", "워크넷", "고용24", "링크드인")

// ─── 비상연락처 ──────────────────────────────────────────────────
data class Contact(val id: Long, val name: String, val number: String, val category: String)

val defaultContacts = listOf(
    Contact(1, "경찰", "112", "긴급"),
    Contact(2, "소방·구급", "119", "긴급"),
    Contact(3, "생활민원 (다산콜)", "120", "생활"),
    Contact(4, "근로복지공단", "1588-0075", "취업"),
    Contact(5, "주거복지재단", "1600-0777", "주거"),
    Contact(6, "청년도약계좌 콜센터", "1397", "금융"),
)

val contactCategories = listOf("긴급", "주거", "취업", "금융", "복지", "기타")

// ─── 챗봇 ────────────────────────────────────────────────────────
val botResponses = mapOf(
    "계약" to "월세 계약 시 꼭 확인할 것: ① 등기부등본 근저당 확인 ② 전입신고 + 확정일자 ③ 특약사항 기재. 계약서 사본은 반드시 보관하세요!",
    "전입" to "전입신고는 계약 후 14일 이내에 주민센터 또는 정부24(www.gov.kr)에서 온라인으로도 가능합니다. 전입신고와 동시에 확정일자를 받으면 보증금이 보호됩니다.",
    "청약" to "청약통장(주택청약종합저축)은 만 19세 이상 누구나 개설 가능합니다. 매월 2~50만 원 납입하며, 납입 횟수와 금액이 청약 당첨에 영향을 줍니다.",
    "월세" to "청년 월세 한시 특별지원을 통해 월 최대 20만 원, 최대 12개월 지원받을 수 있어요. 복지로(www.bokjiro.go.kr)에서 신청하세요.",
    "근로" to "근로계약서는 반드시 서면으로 받아야 합니다. 미작성 시 사업주는 500만 원 이하 벌금. 계약서에는 임금, 근로시간, 휴일, 4대보험 내용이 모두 포함돼야 해요.",
    "퇴직금" to "퇴직금은 1년 이상 근무 + 주 15시간 이상 조건을 충족하면 받을 수 있어요. 퇴직 후 14일 이내에 지급되어야 하며, 미지급 시 고용노동부(1350)에 신고 가능합니다.",
    "보일러" to "보일러 고장은 임대인에게 즉시 연락하고 문자로 증거를 남기세요. 겨울철 동파는 임차인 관리 의무이므로 외출 시 최소 5°C 이상 유지하세요.",
    "지원금" to "대표적인 청년 지원금: 청년 월세 지원(20만 원/월), 청년희망적금, 청년내일채움공제(2년 1,200만 원), 버팀목 전세대출. 자산 탭에서 전체 정책을 확인해 보세요!",
)

const val BOT_DEFAULT_REPLY = "죄송해요, 조금 더 구체적으로 질문해 주시면 도움드릴게요 😊"
const val BOT_GREETING = "안녕하세요! 주거·자산·취업에 관해 궁금한 점을 물어보세요 😊"

fun getBotReply(input: String): String =
    botResponses.entries.firstOrNull { input.contains(it.key) }?.value ?: BOT_DEFAULT_REPLY

val quickQuestions = listOf("계약서 팁", "청약 방법", "월세 지원금", "퇴직금 조건")
