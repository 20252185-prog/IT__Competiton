package com.example.socialbeginner.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.KeyboardArrowRight
import androidx.compose.material.icons.outlined.KeyboardArrowDown
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.socialbeginner.ui.theme.*

@Composable
fun SectionHeader(title: String, subtitle: String? = null, modifier: Modifier = Modifier) {
    Column(modifier.padding(bottom = 16.dp)) {
        Text(title, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = Foreground)
        if (subtitle != null) {
            Spacer(Modifier.height(2.dp))
            Text(subtitle, fontSize = 14.sp, color = MutedForeground)
        }
    }
}

@Composable
fun AppCard(
    modifier: Modifier = Modifier,
    color: Color = CardColor,
    border: Color = BorderColor,
    content: @Composable ColumnScope.() -> Unit,
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        color = color,
        border = BorderStroke(1.dp, border),
        shadowElevation = 1.dp,
    ) {
        Column(content = content)
    }
}

@Composable
fun TagBadge(text: String, background: Color, textColor: Color) {
    Box(
        Modifier
            .clip(RoundedCornerShape(100.dp))
            .background(background)
            .padding(horizontal = 8.dp, vertical = 2.dp)
    ) {
        Text(text, fontSize = 11.sp, fontWeight = FontWeight.Medium, color = textColor)
    }
}

/** "필수" / "권장" / "참고" 태그 색상 */
fun tipTagColors(tag: String): Pair<Color, Color> = when (tag) {
    "필수" -> Red100 to Red700
    "권장" -> Blue100 to Blue700
    else -> Gray100 to Gray600
}

/** 정책·연락처 카테고리 태그 색상 */
fun categoryColors(tag: String): Pair<Color, Color> = when (tag) {
    "긴급" -> Red100 to Red700
    "주거" -> Blue100 to Blue800
    "생활" -> Blue100 to Blue700
    "금융" -> Green100 to Green800
    "취업" -> Purple100 to Purple800
    "복지" -> Orange100 to Orange800
    "교육" -> Yellow100 to Yellow800
    else -> Gray100 to Gray700
}

@Composable
fun BackRow(label: String, onBack: () -> Unit) {
    Row(
        Modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onBack)
            .padding(vertical = 6.dp, horizontal = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text("← $label", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = Accent)
    }
    Spacer(Modifier.height(12.dp))
}

/** 홈 화면의 2열 그리드 섹션 타일 */
@Composable
fun SectionTile(
    icon: ImageVector,
    label: String,
    iconTint: Color,
    iconBackground: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        color = CardColor,
        border = BorderStroke(1.dp, BorderColor),
        shadowElevation = 1.dp,
        onClick = onClick,
    ) {
        Column(Modifier.padding(16.dp)) {
            Box(
                Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(iconBackground),
                contentAlignment = Alignment.Center,
            ) {
                Icon(icon, contentDescription = null, tint = iconTint, modifier = Modifier.size(20.dp))
            }
            Spacer(Modifier.height(12.dp))
            Text(label, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = Foreground, lineHeight = 18.sp)
            Spacer(Modifier.height(8.dp))
            Icon(
                Icons.AutoMirrored.Outlined.KeyboardArrowRight,
                contentDescription = null,
                tint = MutedForeground,
                modifier = Modifier.size(16.dp),
            )
        }
    }
}

@Composable
fun Accordion(title: String, content: @Composable ColumnScope.() -> Unit) {
    var open by rememberSaveable { mutableStateOf(false) }
    val rotation by animateFloatAsState(if (open) 180f else 0f, label = "chevron")
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = CardColor,
        border = BorderStroke(1.dp, BorderColor),
    ) {
        Column {
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable { open = !open }
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    title,
                    modifier = Modifier.weight(1f),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    color = Foreground,
                )
                Icon(
                    Icons.Outlined.KeyboardArrowDown,
                    contentDescription = null,
                    tint = MutedForeground,
                    modifier = Modifier.size(18.dp).rotate(rotation),
                )
            }
            AnimatedVisibility(visible = open) {
                Column(Modifier.padding(start = 16.dp, end = 16.dp, bottom = 16.dp)) {
                    content()
                }
            }
        }
    }
}

/** 번호가 붙은 단계 리스트 (트러블슈팅) */
@Composable
fun NumberedStep(index: Int, text: String) {
    Row(Modifier.padding(vertical = 4.dp)) {
        Box(
            Modifier
                .size(20.dp)
                .clip(CircleShape)
                .background(Accent),
            contentAlignment = Alignment.Center,
        ) {
            Text("$index", fontSize = 11.sp, fontWeight = FontWeight.Medium, color = Color.White)
        }
        Spacer(Modifier.width(10.dp))
        Text(text, fontSize = 14.sp, color = Foreground, lineHeight = 20.sp, modifier = Modifier.weight(1f))
    }
}
