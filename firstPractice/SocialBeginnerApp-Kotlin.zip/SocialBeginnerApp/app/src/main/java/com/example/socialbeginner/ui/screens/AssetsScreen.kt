package com.example.socialbeginner.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.TrendingUp
import androidx.compose.material.icons.outlined.CardGiftcard
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.socialbeginner.data.cheongyakSteps
import com.example.socialbeginner.data.governmentPolicies
import com.example.socialbeginner.data.policyFilters
import com.example.socialbeginner.ui.components.*
import com.example.socialbeginner.ui.theme.*

@Composable
fun AssetsScreen() {
    var activeSection by rememberSaveable { mutableStateOf<String?>(null) }
    BackHandler(enabled = activeSection != null) { activeSection = null }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        when (activeSection) {
            "cheongyak" -> CheongyakSection { activeSection = null }
            "policy" -> PolicySection { activeSection = null }
            else -> AssetsHome { activeSection = it }
        }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
private fun AssetsHome(onSelect: (String) -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(Brush.linearGradient(listOf(Color(0xFF1A3F6F), Color(0xFF2468B2))))
            .padding(20.dp)
    ) {
        Text("자산 가이드", fontSize = 11.sp, fontWeight = FontWeight.Medium, color = Color.White.copy(alpha = 0.7f), letterSpacing = 1.sp)
        Spacer(Modifier.height(4.dp))
        Text("지금 시작하면 늦지 않아", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Spacer(Modifier.height(4.dp))
        Text("청약부터 정부 혜택까지 똑똑하게 챙기기", fontSize = 14.sp, color = Color.White.copy(alpha = 0.8f))
    }
    Spacer(Modifier.height(20.dp))

    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        SectionTile(Icons.AutoMirrored.Outlined.TrendingUp, "청약 가이드", Blue600, Blue50, Modifier.weight(1f)) { onSelect("cheongyak") }
        SectionTile(Icons.Outlined.CardGiftcard, "정부 지원 정책 모아보기", Green600, Green50, Modifier.weight(1f)) { onSelect("policy") }
    }
}

@Composable
private fun CheongyakSection(onBack: () -> Unit) {
    BackRow("자산", onBack)
    SectionHeader("청약 가이드", "내 집 마련 첫 걸음, 청약통장부터 시작")
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        cheongyakSteps.forEach { step ->
            val bg = if (step.highlight) Primary else CardColor
            val titleColor = if (step.highlight) Color.White else Foreground
            val descColor = if (step.highlight) Color.White.copy(alpha = 0.8f) else MutedForeground
            val stepColor = if (step.highlight) Color.White.copy(alpha = 0.6f) else MutedForeground
            AppCard(Modifier.fillMaxWidth(), color = bg, border = if (step.highlight) Primary else BorderColor) {
                Row(Modifier.padding(16.dp)) {
                    Text("STEP ${step.step}", fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = stepColor)
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(step.title, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = titleColor)
                        Spacer(Modifier.height(4.dp))
                        Text(step.desc, fontSize = 12.sp, color = descColor, lineHeight = 18.sp)
                    }
                }
            }
        }
    }
    Spacer(Modifier.height(16.dp))
    AppCard(Modifier.fillMaxWidth(), color = Blue50, border = Blue200) {
        Row(Modifier.padding(16.dp)) {
            Icon(Icons.Outlined.Shield, contentDescription = null, tint = Blue600, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(8.dp))
            Text(
                buildAnnotatedString {
                    withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append("무주택 기간이 길수록 유리합니다. ") }
                    append("청약 점수는 무주택 기간, 부양가족 수, 청약통장 가입 기간으로 결정됩니다.")
                },
                fontSize = 12.sp, color = Blue800, lineHeight = 18.sp,
            )
        }
    }
}

@Composable
private fun PolicySection(onBack: () -> Unit) {
    var activeFilter by rememberSaveable { mutableStateOf("전체") }

    BackRow("자산", onBack)
    SectionHeader("정부 지원 정책", "청년을 위한 지원금·혜택 모아보기")

    Row(
        Modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        policyFilters.forEach { f ->
            val selected = activeFilter == f
            Surface(
                shape = RoundedCornerShape(100.dp),
                color = if (selected) Primary else CardColor,
                border = if (selected) null else androidx.compose.foundation.BorderStroke(1.dp, BorderColor),
                onClick = { activeFilter = f },
            ) {
                Text(
                    f,
                    Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    color = if (selected) Color.White else MutedForeground,
                )
            }
        }
    }
    Spacer(Modifier.height(16.dp))

    val filtered = if (activeFilter == "전체") governmentPolicies else governmentPolicies.filter { it.tag == activeFilter }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        filtered.forEach { policy ->
            val (bg, fg) = categoryColors(policy.tag)
            AppCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Row(Modifier.fillMaxWidth()) {
                        TagBadge(policy.tag, bg, fg)
                        Spacer(Modifier.weight(1f))
                        Text(policy.deadline, fontSize = 12.sp, color = MutedForeground)
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(policy.title, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = Foreground)
                    Spacer(Modifier.height(4.dp))
                    Text(policy.desc, fontSize = 12.sp, color = MutedForeground, lineHeight = 18.sp)
                }
            }
        }
    }
}
