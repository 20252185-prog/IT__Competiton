package com.example.socialbeginner.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.SmartToy
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.socialbeginner.data.BOT_GREETING
import com.example.socialbeginner.data.getBotReply
import com.example.socialbeginner.data.quickQuestions
import com.example.socialbeginner.ui.theme.*

data class ChatMessage(val fromUser: Boolean, val text: String)

@Composable
fun ChatbotOverlay(onClose: () -> Unit) {
    val messages = remember { mutableStateListOf(ChatMessage(false, BOT_GREETING)) }
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    fun send(text: String) {
        if (text.isBlank()) return
        messages.add(ChatMessage(true, text))
        messages.add(ChatMessage(false, getBotReply(text)))
        input = ""
    }

    LaunchedEffect(messages.size) {
        listState.animateScrollToItem(messages.lastIndex)
    }

    Column(Modifier.fillMaxSize().background(Background)) {
        // 헤더
        Surface(color = CardColor, shadowElevation = 1.dp) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    Modifier.size(36.dp).clip(CircleShape).background(Primary),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(Icons.Outlined.SmartToy, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("AI 도우미", fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = Foreground)
                    Text("● 온라인", fontSize = 11.sp, fontWeight = FontWeight.Medium, color = Green500)
                }
                Box(
                    Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(Muted)
                        .clickable(onClick = onClose),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(Icons.Outlined.Close, contentDescription = "닫기", tint = MutedForeground, modifier = Modifier.size(16.dp))
                }
            }
        }

        // 메시지 목록
        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            items(messages) { msg ->
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = if (msg.fromUser) Arrangement.End else Arrangement.Start,
                ) {
                    if (!msg.fromUser) {
                        Box(
                            Modifier.size(28.dp).clip(CircleShape).background(Primary),
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(Icons.Outlined.SmartToy, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                        }
                        Spacer(Modifier.width(8.dp))
                    }
                    Surface(
                        shape = RoundedCornerShape(
                            topStart = if (msg.fromUser) 16.dp else 4.dp,
                            topEnd = if (msg.fromUser) 4.dp else 16.dp,
                            bottomStart = 16.dp,
                            bottomEnd = 16.dp,
                        ),
                        color = if (msg.fromUser) Primary else CardColor,
                        border = if (msg.fromUser) null else BorderStroke(1.dp, BorderColor),
                        modifier = Modifier.widthIn(max = 280.dp),
                    ) {
                        Text(
                            msg.text,
                            Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                            fontSize = 14.sp,
                            lineHeight = 20.sp,
                            color = if (msg.fromUser) Color.White else Foreground,
                        )
                    }
                }
            }
        }

        // 빠른 질문
        if (messages.size <= 3) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                quickQuestions.forEach { q ->
                    Surface(
                        shape = RoundedCornerShape(100.dp),
                        color = Secondary,
                        border = BorderStroke(1.dp, BorderColor),
                        onClick = { send(q) },
                    ) {
                        Text(q, Modifier.padding(horizontal = 12.dp, vertical = 6.dp), fontSize = 12.sp, fontWeight = FontWeight.Medium, color = Primary)
                    }
                }
            }
        }

        // 입력창
        Surface(color = CardColor, shadowElevation = 4.dp) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Muted)
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                BasicTextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier.weight(1f),
                    textStyle = TextStyle(fontSize = 14.sp, color = Foreground),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = { send(input) }),
                    singleLine = true,
                    decorationBox = { inner ->
                        Box {
                            if (input.isEmpty()) {
                                Text("질문을 입력하세요...", fontSize = 14.sp, color = MutedForeground)
                            }
                            inner()
                        }
                    },
                )
                Spacer(Modifier.width(8.dp))
                Box(
                    Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(if (input.isBlank()) Primary.copy(alpha = 0.4f) else Primary)
                        .clickable(enabled = input.isNotBlank()) { send(input) },
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "보내기", tint = Color.White, modifier = Modifier.size(14.dp))
                }
            }
        }
    }
}
