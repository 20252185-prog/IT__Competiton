package com.example.socialbeginner.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Assignment
import androidx.compose.material.icons.automirrored.outlined.KeyboardArrowRight
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.ErrorOutline
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.socialbeginner.data.contractGuideItems
import com.example.socialbeginner.data.jobCategories
import com.example.socialbeginner.data.jobSites
import com.example.socialbeginner.ui.components.*
import com.example.socialbeginner.ui.theme.*

@Composable
fun EmploymentScreen() {
    var activeSection by rememberSaveable { mutableStateOf<String?>(null) }
    BackHandler(enabled = activeSection != null) { activeSection = null }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        when (activeSection) {
            "contract" -> WorkContractSection { activeSection = null }
            "jobs" -> JobsSection { activeSection = null }
            else -> EmploymentHome { activeSection = it }
        }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
private fun EmploymentHome(onSelect: (String) -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(Brush.linearGradient(listOf(Color(0xFF1F3A5F), Color(0xFF3B6EA5))))
            .padding(20.dp)
    ) {
        Text("취업 가이드", fontSize = 11.sp, fontWeight = FontWeight.Medium, color = Color.White.copy(alpha = 0.7f), letterSpacing = 1.sp)
        Spacer(Modifier.height(4.dp))
        Text("내 권리는 내가 지킨다", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Spacer(Modifier.height(4.dp))
        Text("계약서부터 취업 채널까지 한 번에", fontSize = 14.sp, color = Color.White.copy(alpha = 0.8f))
    }
    Spacer(Modifier.height(20.dp))

    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        SectionTile(Icons.AutoMirrored.Outlined.Assignment, "근로계약서 가이드", Red500, Red50, Modifier.weight(1f)) { onSelect("contract") }
        SectionTile(Icons.Outlined.Search, "직종별 취업 모아보기", Purple600, Purple50, Modifier.weight(1f)) { onSelect("jobs") }
    }
    Spacer(Modifier.height(20.dp))

    AppCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text("주요 구직 사이트", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = MutedForeground, letterSpacing = 1.sp)
            Spacer(Modifier.height(8.dp))
            jobSites.forEachIndexed { i, name ->
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(name, fontSize = 14.sp, color = Foreground, modifier = Modifier.weight(1f))
                    Icon(Icons.AutoMirrored.Outlined.KeyboardArrowRight, contentDescription = null, tint = MutedForeground, modifier = Modifier.size(16.dp))
                }
                if (i < jobSites.lastIndex) HorizontalDivider(color = BorderColor)
            }
        }
    }
}

@Composable
private fun WorkContractSection(onBack: () -> Unit) {
    BackRow("취업", onBack)
    SectionHeader("근로계약서 가이드", "서명 전, 이것만은 꼭 확인하세요")
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        contractGuideItems.forEach { item ->
            AppCard(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(16.dp)) {
                    // important 항목은 왼쪽 빨간 스트라이프 느낌으로 아이콘 강조
                    Icon(
                        if (item.important) Icons.Outlined.ErrorOutline else Icons.Outlined.Check,
                        contentDescription = null,
                        tint = if (item.important) Red500 else Green500,
                        modifier = Modifier.size(16.dp),
                    )
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(item.title, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = Foreground)
                        Spacer(Modifier.height(4.dp))
                        Text(item.desc, fontSize = 12.sp, color = MutedForeground, lineHeight = 18.sp)
                    }
                }
            }
        }
    }
    Spacer(Modifier.height(16.dp))
    AppCard(Modifier.fillMaxWidth(), color = Orange50, border = Orange200) {
        Column(Modifier.padding(16.dp)) {
            Text("💡 이럴 때는 고용노동부에 신고하세요", fontSize = 12.sp, fontWeight = FontWeight.Medium, color = Orange800)
            Spacer(Modifier.height(4.dp))
            Text(
                "근로계약서 미작성, 임금 체불, 부당해고 시 고용노동부 (1350) 또는 고용24 앱에서 신고 가능합니다.",
                fontSize = 12.sp, color = Orange700, lineHeight = 18.sp,
            )
        }
    }
}

@Composable
private fun JobsSection(onBack: () -> Unit) {
    BackRow("취업", onBack)
    SectionHeader("직종별 취업 정보", "내게 맞는 직종을 찾아보세요")
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        jobCategories.forEach { cat ->
            AppCard(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(16.dp)) {
                    Text(cat.icon, fontSize = 24.sp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(cat.name, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = Foreground)
                        Spacer(Modifier.height(4.dp))
                        Text(cat.tip, fontSize = 12.sp, color = MutedForeground, lineHeight = 18.sp)
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            cat.sites.forEach { site -> TagBadge(site, Secondary, Primary) }
                        }
                    }
                }
            }
        }
    }
}
