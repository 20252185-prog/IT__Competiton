package com.example.socialbeginner.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.MenuBook
import androidx.compose.material.icons.outlined.CheckBox
import androidx.compose.material.icons.outlined.CheckBoxOutlineBlank
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.ErrorOutline
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.socialbeginner.data.checklistItems
import com.example.socialbeginner.data.contractTips
import com.example.socialbeginner.data.housingTerms
import com.example.socialbeginner.data.troubleshootingItems
import com.example.socialbeginner.ui.components.*
import com.example.socialbeginner.ui.theme.*

@Composable
fun HousingScreen() {
    var activeSection by rememberSaveable { mutableStateOf<String?>(null) }
    val checkedItems = remember { mutableStateListOf<Int>() }

    BackHandler(enabled = activeSection != null) { activeSection = null }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        when (activeSection) {
            "terms" -> TermsSection { activeSection = null }
            "checklist" -> ChecklistSection(checkedItems) { activeSection = null }
            "trouble" -> TroubleSection { activeSection = null }
            "contract" -> ContractTipsSection { activeSection = null }
            else -> HousingHome { activeSection = it }
        }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
private fun HousingHome(onSelect: (String) -> Unit) {
    // 히어로 배너
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(Primary)
            .padding(20.dp)
    ) {
        Text("주거 가이드", fontSize = 11.sp, fontWeight = FontWeight.Medium, color = Color.White.copy(alpha = 0.7f), letterSpacing = 1.sp)
        Spacer(Modifier.height(4.dp))
        Text("혼자 살기, 처음이라도 괜찮아", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Spacer(Modifier.height(4.dp))
        Text("계약부터 생활까지 알아야 할 모든 것", fontSize = 14.sp, color = Color.White.copy(alpha = 0.8f))
    }
    Spacer(Modifier.height(20.dp))

    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        SectionTile(Icons.AutoMirrored.Outlined.MenuBook, "기본 용어 설명", Purple600, Purple50, Modifier.weight(1f)) { onSelect("terms") }
        SectionTile(Icons.Outlined.CheckBox, "방 구하기 체크리스트", Green600, Green50, Modifier.weight(1f)) { onSelect("checklist") }
    }
    Spacer(Modifier.height(12.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        SectionTile(Icons.Outlined.ErrorOutline, "트러블슈팅 가이드", Orange600, Orange50, Modifier.weight(1f)) { onSelect("trouble") }
        SectionTile(Icons.Outlined.Description, "계약서 팁", Blue600, Blue50, Modifier.weight(1f)) { onSelect("contract") }
    }
}

@Composable
private fun ContractTipsSection(onBack: () -> Unit) {
    BackRow("주거", onBack)
    SectionHeader("월세 계약서 팁", "계약 전후 반드시 확인해야 할 체크포인트")
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        contractTips.forEach { tip ->
            val (bg, fg) = tipTagColors(tip.tag)
            AppCard(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(16.dp)) {
                    Column(Modifier.weight(1f)) {
                        Text(tip.title, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = Foreground)
                        Spacer(Modifier.height(4.dp))
                        Text(tip.desc, fontSize = 12.sp, color = MutedForeground, lineHeight = 18.sp)
                    }
                    Spacer(Modifier.width(12.dp))
                    TagBadge(tip.tag, bg, fg)
                }
            }
        }
    }
}

@Composable
private fun ChecklistSection(checkedItems: MutableList<Int>, onBack: () -> Unit) {
    BackRow("주거", onBack)
    SectionHeader("자취방 구하기 체크리스트")

    val progress = checkedItems.size
    val total = checklistItems.size

    AppCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Row(Modifier.fillMaxWidth()) {
                Text("$progress / $total 완료", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = Foreground, modifier = Modifier.weight(1f))
                Text("${(progress * 100) / total}%", fontSize = 12.sp, color = MutedForeground)
            }
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(
                progress = { progress.toFloat() / total },
                modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(100.dp)),
                color = Accent,
                trackColor = Muted,
            )
        }
    }
    Spacer(Modifier.height(16.dp))

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        checklistItems.forEach { (id, text) ->
            val checked = id in checkedItems
            AppCard(Modifier.fillMaxWidth()) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { if (checked) checkedItems.remove(id) else checkedItems.add(id) }
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(
                        if (checked) Icons.Outlined.CheckBox else Icons.Outlined.CheckBoxOutlineBlank,
                        contentDescription = null,
                        tint = if (checked) Accent else MutedForeground,
                        modifier = Modifier.size(20.dp),
                    )
                    Spacer(Modifier.width(12.dp))
                    Text(
                        text,
                        fontSize = 14.sp,
                        color = if (checked) MutedForeground else Foreground,
                        textDecoration = if (checked) TextDecoration.LineThrough else null,
                    )
                }
            }
        }
    }
}

@Composable
private fun TroubleSection(onBack: () -> Unit) {
    BackRow("주거", onBack)
    SectionHeader("트러블슈팅 가이드", "자취 중 자주 발생하는 문제와 대처법")
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        troubleshootingItems.forEach { item ->
            Accordion("${item.icon} ${item.title}") {
                item.steps.forEachIndexed { i, step -> NumberedStep(i + 1, step) }
            }
        }
    }
}

@Composable
private fun TermsSection(onBack: () -> Unit) {
    BackRow("주거", onBack)
    SectionHeader("자취 기본 용어", "헷갈리기 쉬운 부동산·임대차 용어 정리")
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        housingTerms.forEach { item ->
            AppCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text(item.term, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = Accent)
                    Spacer(Modifier.height(4.dp))
                    Text(item.def, fontSize = 12.sp, color = MutedForeground, lineHeight = 18.sp)
                }
            }
        }
    }
}
