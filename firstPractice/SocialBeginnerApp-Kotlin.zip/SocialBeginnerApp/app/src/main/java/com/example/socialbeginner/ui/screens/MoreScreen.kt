package com.example.socialbeginner.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.KeyboardArrowRight
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Phone
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.socialbeginner.data.Contact
import com.example.socialbeginner.data.contactCategories
import com.example.socialbeginner.data.defaultContacts
import com.example.socialbeginner.ui.components.*
import com.example.socialbeginner.ui.theme.*

@Composable
fun MoreScreen() {
    var activeSection by rememberSaveable { mutableStateOf<String?>(null) }
    val contacts = remember { mutableStateListOf(*defaultContacts.toTypedArray()) }

    BackHandler(enabled = activeSection != null) { activeSection = null }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        when (activeSection) {
            "contacts" -> ContactsSection(contacts) { activeSection = null }
            else -> MoreHome(contacts.size) { activeSection = it }
        }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
private fun MoreHome(contactCount: Int, onSelect: (String) -> Unit) {
    Text("기능", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = MutedForeground, letterSpacing = 1.sp)
    Spacer(Modifier.height(8.dp))
    AppCard(Modifier.fillMaxWidth()) {
        Row(
            Modifier
                .fillMaxWidth()
                .clickable { onSelect("contacts") }
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Outlined.Phone, contentDescription = null, tint = MutedForeground, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(12.dp))
            Text("비상연락처", fontSize = 14.sp, color = Foreground, modifier = Modifier.weight(1f))
            TagBadge("${contactCount}개", Secondary, Primary)
            Spacer(Modifier.width(8.dp))
            Icon(Icons.AutoMirrored.Outlined.KeyboardArrowRight, contentDescription = null, tint = MutedForeground, modifier = Modifier.size(16.dp))
        }
    }

    Spacer(Modifier.height(20.dp))
    Text("앱 정보", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = MutedForeground, letterSpacing = 1.sp)
    Spacer(Modifier.height(8.dp))
    AppCard(Modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("공지사항", fontSize = 14.sp, color = Foreground, modifier = Modifier.weight(1f))
            Icon(Icons.AutoMirrored.Outlined.KeyboardArrowRight, contentDescription = null, tint = MutedForeground, modifier = Modifier.size(16.dp))
        }
    }
}

@Composable
private fun ContactsSection(contacts: MutableList<Contact>, onBack: () -> Unit) {
    val context = LocalContext.current
    var showAddForm by rememberSaveable { mutableStateOf(false) }
    var newName by rememberSaveable { mutableStateOf("") }
    var newNumber by rememberSaveable { mutableStateOf("") }
    var newCategory by rememberSaveable { mutableStateOf("기타") }

    BackRow("더보기", onBack)

    Row(verticalAlignment = Alignment.Top) {
        Box(Modifier.weight(1f)) {
            SectionHeader("비상연락처", "긴급 상황 시 빠르게 연락하세요")
        }
        Button(
            onClick = { showAddForm = !showAddForm },
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Primary),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
        ) {
            Icon(Icons.Outlined.Add, contentDescription = null, modifier = Modifier.size(14.dp))
            Spacer(Modifier.width(6.dp))
            Text("추가", fontSize = 12.sp)
        }
    }

    if (showAddForm) {
        AppCard(Modifier.fillMaxWidth(), border = Accent) {
            Column(Modifier.padding(16.dp)) {
                Text("새 연락처 추가", fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = Foreground)
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = newName,
                    onValueChange = { newName = it },
                    placeholder = { Text("이름 (예: 집주인)", fontSize = 14.sp, color = MutedForeground) },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Accent, unfocusedBorderColor = BorderColor),
                )
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = newNumber,
                    onValueChange = { newNumber = it },
                    placeholder = { Text("전화번호", fontSize = 14.sp, color = MutedForeground) },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Accent, unfocusedBorderColor = BorderColor),
                )
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    contactCategories.forEach { c ->
                        val selected = newCategory == c
                        Surface(
                            shape = RoundedCornerShape(100.dp),
                            color = if (selected) Primary else CardColor,
                            border = if (selected) null else BorderStroke(1.dp, BorderColor),
                            onClick = { newCategory = c },
                        ) {
                            Text(
                                c,
                                Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                                fontSize = 12.sp,
                                color = if (selected) Color.White else MutedForeground,
                            )
                        }
                    }
                }
                Spacer(Modifier.height(14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            if (newName.isNotBlank() && newNumber.isNotBlank()) {
                                contacts.add(Contact(System.currentTimeMillis(), newName, newNumber, newCategory))
                                newName = ""; newNumber = ""; newCategory = "기타"
                                showAddForm = false
                            }
                        },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Primary),
                    ) { Text("저장", fontSize = 14.sp) }
                    TextButton(
                        onClick = { showAddForm = false },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp),
                    ) { Text("취소", fontSize = 14.sp, color = MutedForeground) }
                }
            }
        }
        Spacer(Modifier.height(16.dp))
    }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        contacts.forEach { contact ->
            val (bg, fg) = categoryColors(contact.category)
            AppCard(Modifier.fillMaxWidth()) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable {
                            context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${contact.number}")))
                        }
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Outlined.Phone, contentDescription = null, tint = MutedForeground, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(contact.name, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = Foreground)
                        Text(contact.number, fontSize = 12.sp, color = MutedForeground)
                    }
                    TagBadge(contact.category, bg, fg)
                    if (contact.id > 6) {
                        Spacer(Modifier.width(8.dp))
                        Icon(
                            Icons.Outlined.Close,
                            contentDescription = "삭제",
                            tint = MutedForeground,
                            modifier = Modifier
                                .size(16.dp)
                                .clickable { contacts.removeAll { it.id == contact.id } },
                        )
                    }
                }
            }
        }
    }
}
