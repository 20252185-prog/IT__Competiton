package com.example.socialbeginner.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Figma theme.css 색상 그대로
val Background = Color(0xFFF5F7FA)
val Foreground = Color(0xFF0E1B2A)
val CardColor = Color(0xFFFFFFFF)
val Primary = Color(0xFF1A3F6F)
val PrimaryLight = Color(0xFF2468B2)
val Secondary = Color(0xFFEBF0F7)
val Muted = Color(0xFFEEF1F6)
val Accent = Color(0xFF2468B2)
val BorderColor = Color(0x1F1A3F6F) // 12% alpha of #1A3F6F
val MutedForeground = Color(0xFF5B6B7F)

// 태그/뱃지 색 (Tailwind 100/700~800 계열)
val Red100 = Color(0xFFFEE2E2); val Red700 = Color(0xFFB91C1C); val Red500 = Color(0xFFEF4444)
val Blue100 = Color(0xFFDBEAFE); val Blue700 = Color(0xFF1D4ED8); val Blue800 = Color(0xFF1E40AF)
val Blue50 = Color(0xFFEFF6FF); val Blue200 = Color(0xFFBFDBFE); val Blue600 = Color(0xFF2563EB)
val Green100 = Color(0xFFDCFCE7); val Green700 = Color(0xFF15803D); val Green800 = Color(0xFF166534)
val Green50 = Color(0xFFF0FDF4); val Green600 = Color(0xFF16A34A); val Green500 = Color(0xFF22C55E)
val Purple100 = Color(0xFFF3E8FF); val Purple700 = Color(0xFF7E22CE); val Purple800 = Color(0xFF6B21A8)
val Purple50 = Color(0xFFFAF5FF); val Purple600 = Color(0xFF9333EA)
val Orange100 = Color(0xFFFFEDD5); val Orange800 = Color(0xFF9A3412); val Orange700 = Color(0xFFC2410C)
val Orange50 = Color(0xFFFFF7ED); val Orange200 = Color(0xFFFED7AA); val Orange600 = Color(0xFFEA580C)
val Yellow100 = Color(0xFFFEF9C3); val Yellow700 = Color(0xFFA16207); val Yellow800 = Color(0xFF854D0E)
val Yellow50 = Color(0xFFFEFCE8)
val Gray100 = Color(0xFFF3F4F6); val Gray600 = Color(0xFF4B5563); val Gray700 = Color(0xFF374151)
val Red50 = Color(0xFFFEF2F2); val Red400 = Color(0xFFF87171); val Red800 = Color(0xFF991B1B)

private val LightColors = lightColorScheme(
    primary = Primary,
    onPrimary = Color.White,
    secondary = Secondary,
    onSecondary = Primary,
    tertiary = Accent,
    background = Background,
    onBackground = Foreground,
    surface = CardColor,
    onSurface = Foreground,
    surfaceVariant = Muted,
    onSurfaceVariant = MutedForeground,
    outline = BorderColor,
)

@Composable
fun SocialBeginnerTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = LightColors, content = content)
}
